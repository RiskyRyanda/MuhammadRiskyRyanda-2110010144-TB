/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author USER
 */
public class login_helper {
    String Username;
    String Password;
    
    public login_helper(String Username, String Password){
        this.Username = Username;
        this.Password = Password;
    } 
}

